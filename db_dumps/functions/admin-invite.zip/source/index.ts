// Setup type definitions for built-in Supabase Runtime APIs
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

type ReqPayload = { email: string };

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

console.info("admin-invite function started");

Deno.serve(async (req: Request) => {
  // ✅ CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return json({ error: "Method not allowed" }, 405);
    }

    // 1) JWT caller (depuis le front)
    const authHeader =
      req.headers.get("authorization") ??
      req.headers.get("Authorization") ??
      "";

    if (!authHeader.startsWith("Bearer ")) {
      return json({ error: "Missing Authorization bearer token" }, 401);
    }

    // 2) Payload
    const { email } = (await req.json().catch(() => ({}))) as Partial<ReqPayload>;
    if (!email || typeof email !== "string") {
      return json({ error: "Missing/invalid email" }, 400);
    }

    // 3) Env
    const url = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!url || !anonKey || !serviceRoleKey) {
      return json(
        {
          error:
            "Missing env vars. Need SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY",
        },
        500
      );
    }

    // 4) Client user (vérif identité + role admin via profiles)
    const userClient = createClient(url, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user) {
      return json({ error: "Unauthorized" }, 401);
    }

    const callerId = userData.user.id;

    const { data: profile, error: profErr } = await userClient
      .from("profiles")
      .select("role")
      .eq("id", callerId)
      .maybeSingle();

    if (profErr) {
      return json({ error: "Cannot read profile role" }, 500);
    }
    if (profile?.role !== "admin") {
      return json({ error: "Forbidden (admin only)" }, 403);
    }

    // 5) Client admin (service role) → invite
    const adminClient = createClient(url, serviceRoleKey);

    const { data: invited, error: invErr } =
      await adminClient.auth.admin.inviteUserByEmail(email);

    if (invErr) {
      return json({ error: invErr.message }, 400);
    }

    return json({ ok: true, invited_user_id: invited.user?.id ?? null }, 200);
  } catch (e) {
    return json({ error: String((e as any)?.message ?? e) }, 500);
  }
});