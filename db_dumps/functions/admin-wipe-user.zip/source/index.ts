import { serve } from "https://deno.land/std@0.192.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders })
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE)

    const body = await req.json()
    const targetUserId = body?.targetUserId || body?.userId
    const mode = body?.mode || "all"

    if (!targetUserId) {
      return new Response(
        JSON.stringify({ error: "targetUserId required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      )
    }

    // ------------------------------------------------
    // 1) récupérer trips du user
    // ------------------------------------------------
    const { data: trips, error: tripsErr } = await admin
      .from("trip_groups")
      .select("id")
      .eq("user_id", targetUserId)

    if (tripsErr) throw tripsErr

    const tripIds = (trips || []).map((t) => t.id)

    // ------------------------------------------------
    // 2) neutraliser références transactions liées aux trips
    // ------------------------------------------------
    if (tripIds.length) {
      const { data: settlementTx, error: settlementTxErr } = await admin
        .from("trip_settlement_events")
        .select("transaction_id")
        .in("trip_id", tripIds)

      if (settlementTxErr) throw settlementTxErr

      const settlementTxIds = (settlementTx || [])
        .map((t) => t.transaction_id)
        .filter(Boolean)

      if (settlementTxIds.length) {
        const { error } = await admin
          .from("transactions")
          .update({
            trip_share_link_id: null,
            trip_expense_id: null,
          })
          .in("id", settlementTxIds)

        if (error) throw error
      }

      const { data: expenseRows, error: expenseRowsErr } = await admin
        .from("trip_expenses")
        .select("id")
        .in("trip_id", tripIds)

      if (expenseRowsErr) throw expenseRowsErr

      const expenseIds = (expenseRows || []).map((e) => e.id)

      if (expenseIds.length) {
        const { error: detachTx } = await admin
          .from("transactions")
          .update({ trip_expense_id: null })
          .in("trip_expense_id", expenseIds)

        if (detachTx) throw detachTx

        const { error: detachExpense } = await admin
          .from("trip_expenses")
          .update({ transaction_id: null })
          .in("id", expenseIds)

        if (detachExpense) throw detachExpense
      }

      // ------------------------------------------------
      // 3) suppression tables trip
      // ------------------------------------------------
      const deletions = [
        admin.from("trip_expense_budget_links").delete().in("trip_id", tripIds),
        admin.from("trip_expense_shares").delete().in("trip_id", tripIds),
        admin.from("trip_settlement_events").delete().in("trip_id", tripIds),
        admin.from("trip_settlements").delete().in("trip_id", tripIds),
        admin.from("trip_expenses").delete().in("trip_id", tripIds),
        admin.from("trip_members").delete().in("trip_id", tripIds),
        admin.from("trip_participants").delete().in("trip_id", tripIds),
        admin.from("trip_invites").delete().in("trip_id", tripIds),
        admin.from("trip_groups").delete().in("id", tripIds),
      ]

      for (const q of deletions) {
        const { error } = await q
        if (error) throw error
      }
    }

    // ------------------------------------------------
    // 4) suppression données utilisateur
    // ordre important :
    // transactions -> recurring_rules -> wallets -> budget_segments
    // -> periods -> travels -> fx/settings/categories
    // ------------------------------------------------

    {
      const { error } = await admin
        .from("transactions")
        .delete()
        .eq("user_id", targetUserId)

      if (error) throw error
    }

    {
      const { error } = await admin
        .from("recurring_rules")
        .delete()
        .eq("user_id", targetUserId)

      if (error) throw error
    }

    {
      const { error } = await admin
        .from("wallets")
        .delete()
        .eq("user_id", targetUserId)

      if (error) throw error
    }

    {
      const { error } = await admin
        .from("budget_segments")
        .delete()
        .eq("user_id", targetUserId)

      if (error) throw error
    }

    {
      const { error } = await admin
        .from("periods")
        .delete()
        .eq("user_id", targetUserId)

      if (error) throw error
    }

    {
      const { error } = await admin
        .from("travels")
        .delete()
        .eq("user_id", targetUserId)

      if (error) throw error
    }

    {
      const { error } = await admin
        .from("fx_manual_rates")
        .delete()
        .eq("user_id", targetUserId)

      if (error) throw error
    }

    if (mode === "all") {
      const { error: settingsErr } = await admin
        .from("settings")
        .delete()
        .eq("user_id", targetUserId)

      if (settingsErr) throw settingsErr

      const { error: catErr } = await admin
        .from("categories")
        .delete()
        .eq("user_id", targetUserId)

      if (catErr) throw catErr
    }

    // ------------------------------------------------
    // 5) réponse succès
    // ------------------------------------------------
    return new Response(
      JSON.stringify({
        success: true,
        message: "Reset utilisateur terminé avec succès (travels + règles récurrentes inclus).",
        wipedTrips: tripIds.length,
        mode,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    )
  } catch (err) {
    return new Response(
      JSON.stringify({
        error: err?.message || String(err),
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    )
  }
})